n= int(input("número fatorial?"))

if n<0:
	print ("Erro")
	exit

for n in range (n, 0, -1):
	
