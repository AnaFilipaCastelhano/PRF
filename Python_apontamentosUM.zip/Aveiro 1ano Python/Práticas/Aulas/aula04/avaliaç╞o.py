Un = 100                    

i=0
while Un>0:
	print(Un)
	Un = 1.01*Un - 1.01     
	i=i+1
	
print ("número total de termos é:",i)
