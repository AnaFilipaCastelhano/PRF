nome=input ("Como te chamas?")
ano=int(input ("Em que ano nasceste?"))
idade=2020 - ano
print (nome , " em 2020 farás ", idade, "anos.")
