# Example program developed in TP class.
# jmr@ua.pt 2018

# A small program with operations on integers.

n = int( input("Quantos ovos tens? ") )
print("Com", n, "ovos")
print("podes encher", n//6, "caixas")
print("e sobram", n%6, "ovos")

