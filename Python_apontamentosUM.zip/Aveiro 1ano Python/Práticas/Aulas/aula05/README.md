# Bibliografia para a aula 05.

* Slides e guião disponibilizados nesta pasta.
* [1, caps. 9 e 10] ou [2, caps. 8, 10 e 12].

# Trabalho para casa (Homework)

Ler e resolver os exercícios referentes a esta aula do livro recomendado [1].
Resolver os primeiros exercícios do guião antes da aula prática.

[1] [How to Think Like a Computer Scientist: Interactive Edition](https://runestone.academy/runestone/static/thinkcspy/index.html)

[2] [Think Python 2e](http://greenteapress.com/wp/think-python-2e/)
