x= float(input("numero de litros?"))

preço=x*1.4

if x>40:
	preço= 0.9*x
else:
	preço==preço

print (preço,"euros")
