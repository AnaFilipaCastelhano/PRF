x= int(input("numero?"))

if x%2 == 0:
	print ("par")
else:
	print ("impar")
