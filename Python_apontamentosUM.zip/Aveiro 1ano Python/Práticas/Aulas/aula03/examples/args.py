def func(a, b, c):
    print(a, b, c)

