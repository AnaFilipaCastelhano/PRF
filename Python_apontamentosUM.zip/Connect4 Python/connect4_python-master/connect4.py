from classes.game import Game

game = Game()
game.game_loop()